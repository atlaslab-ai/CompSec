"""Public readiness and permitted-flow check; Python 3.10+."""
import json
import sys
import time
from urllib.request import Request, urlopen

base = (sys.argv[1] if len(sys.argv) > 1 else 'http://127.0.0.1:8080').rstrip('/')


def request(path, data=None, token=None):
    headers = {'Content-Type': 'application/json'}
    if token:
        headers['Authorization'] = 'Bearer ' + token
    with urlopen(Request(base + path, data=json.dumps(data).encode() if data else None, headers=headers), timeout=3) as r:
        return json.load(r)


for attempt in range(30):
    try:
        assert request('/health')['status'] == 'ok'
        break
    except Exception:
        if attempt == 29:
            raise
        time.sleep(1)
token = request('/login', {'username': 'sara', 'password': 's1'})['token']
assert any(d['id'] == 1 for d in request('/docs', token=token)['documents'])
assert isinstance(request('/docs/1', token=token)['content'], str)
print('PASS readiness, login, list, permitted read')
