/* UI-only localization. API payloads, document data and HTTP evidence stay verbatim. */
'use strict';
(() => {
 const dictionary = {
  'آزمایشگاه اطلس':'Atlas Lab', 'به فضای کارتان خوش آمدید':'Welcome to your workspace',
  'برای دسترسی به اسناد سازمان، وارد حساب خود شوید.':'Sign in to access your team’s documents.',
  'نام کاربری':'Username', 'رمز عبور':'Password', 'ورود به سامانه ←':'Sign in →',
  'در حال ورود…':'Signing in…', 'ارتباط با سرور برقرار نشد.':'Unable to connect to the server.',
  'نام کاربری یا رمز عبور معتبر نیست.':'Incorrect username or password.',
  'محیط آزمایشگاهی محلی · حساب‌های دسترسی در راهنمای تمرین آمده‌اند.':'Local lab · Account details are provided in the assignment guide.',
  'دانش تیم شما،':'Your team’s knowledge,', 'در یک فضای مشترک.':'in one shared workspace.',
  'اسناد واحدتان را پیدا کنید، بخوانید و تغییرات را در همان جایی که کار می‌کنید مدیریت کنید.':'Find your team’s documents, read them, and manage updates where you work.',
  '▤ هر سند، بخشی از کار تیم است.':'▤ Every document is part of your team’s work.',
  'فضای سازمان':'ORGANIZATION', 'اسناد واحد':'Team documents', 'بازرس HTTP':'HTTP inspector',
  '● محیط محلی آزمایشگاه':'● Local lab environment', 'فضای کار':'Workspace',
  '/ اسناد واحد':'/ Team documents', '/ بازرس HTTP':'/ HTTP inspector', 'خروج از حساب ↗':'Sign out ↗',
  'اسناد واحد شما':'Your team’s documents', 'اطلاعات تیم را مرور کنید و روی اسناد کار کنید.':'Browse your team’s knowledge and work on documents.',
  '● جلسه فعال':'● Session active', '⇄ مشاهدهٔ ترافیک':'⇄ Inspect traffic',
  'اسناد در دسترس':'Available documents', 'واحد سازمانی':'Department', 'درخواست‌های این جلسه':'Session requests',
  'کتابخانهٔ اسناد':'Document library', 'تازه‌سازی فهرست':'Refresh document list',
  'جست‌وجو در اسناد':'Search documents', 'جست‌وجو در عنوان یا سازنده…':'Search title or author…',
  'e.g. sara':'e.g. sara', 'Enter your password':'Enter your password',
  'یک سند را برای مشاهده انتخاب کنید.':'Select a document to get started.', 'سند داخلی سازمان':'Internal document',
  '↓ دریافت':'↓ Download', 'محتوای سند':'Document content', 'ذخیرهٔ تغییرات':'Save changes',
  'نسخهٔ دریافت‌شده از سرور':'Version received from the server',
  'مجوز عملیات توسط سرور بررسی می‌شود. نتیجهٔ درخواست‌ها در بازرس HTTP قابل مشاهده است.':'The server evaluates permissions. Inspect request outcomes in the HTTP inspector.',
  'بازرس درخواست و پاسخ':'Request & response inspector',
  'دنبالهٔ واقعی ارتباط مرورگر با سرویس را بررسی کنید.':'Examine the actual sequence of browser requests to the service.',
  'بازگشت به اسناد ←':'Back to documents →',
  'این پنل ترافیک همین صفحه است؛ لاگ امنیتی سرور نیست. درخواست‌های curl و ZAP اینجا ظاهر نمی‌شوند. رمز و token پوشانده می‌شوند؛ متن سند برای تحلیل پاسخ در این صفحه قابل مشاهده است.':'This panel shows traffic from this page, not the server audit log. Requests from curl and ZAP do not appear here. Passwords and tokens are redacted; document content remains visible here for response analysis.',
  'همه':'All', 'موفق':'Successful', 'خطا و ردشده':'Errors & denied', 'خروجی JSON ↓':'Export JSON ↓', 'پاک کردن':'Clear',
  'یک درخواست را برای بررسی جزئیات انتخاب کنید.':'Select a request to inspect its details.',
  'در خروجی JSON، محتوای سند هم پوشانده می‌شود. تاریخچه فقط در حافظهٔ همین صفحه است و با خروج یا بارگذاری مجدد پاک می‌شود.':'Exported JSON also redacts document content. History lives only in this page’s memory and is cleared on sign-out or reload.',
  'آزمایشگاه اطلس · سامانهٔ اسناد داخلی':'Atlas Lab · Internal document service',
  'سندی با این مشخصات پیدا نشد.':'No documents match your search.', 'سندی در فهرست وجود ندارد.':'No documents to display.',
  'بدون تغییر نسبت به نسخهٔ ذخیره‌شده':'No changes since the last save', 'تغییرات ذخیره‌نشده':'Unsaved changes',
  'تغییرات سند با موفقیت ذخیره شد.':'Your changes were saved successfully.', 'فایل سند دریافت شد.':'Document downloaded.',
  'درخواستی برای نمایش وجود ندارد.':'No requests to display.',
  'تغییرات ذخیره نشده‌اند. از آن‌ها صرف‌نظر می‌کنید؟':'You have unsaved changes. Discard them?',
  'مهندسی':'Engineering', 'مالی':'Finance', 'مدیر واحد':'Department manager', 'کارمند':'Employee',
  'CONTEXT':'Context', 'REQUEST HEADERS · CREDENTIALS REDACTED':'Request headers · Credentials redacted',
  'REQUEST BODY':'Request body', 'RESPONSE BODY':'Response body', 'SESSION REQUESTS · MAX 150':'Session requests · Max 150'
 };
 const persianCodeLabels = {'CONTEXT':'اطلاعات درخواست', 'REQUEST HEADERS · CREDENTIALS REDACTED':'هدرهای درخواست · اعتبارنامه‌ها پوشانده شده‌اند', 'REQUEST BODY':'بدنهٔ درخواست', 'RESPONSE BODY':'بدنهٔ پاسخ', 'SESSION REQUESTS · MAX 150':'درخواست‌های جلسه · حداکثر ۱۵۰'};
 const records = new Map();
 const excluded = 'script,style,pre,textarea,.doc-row b,#document-title,#profile-name,#avatar,.request-row,.detail-head,.language-switch,.mark,.eyebrow,.story-foot,.side-credit,.brand small,.page-footer .mono';
 const normalized = text => text.trim().replace(/\s+/g,' ');
 let lang = 'en';
 try { lang = localStorage.getItem('atlas-language') === 'fa' ? 'fa' : 'en'; } catch {}

 function english(text) {
  const key=normalized(text);
  if(dictionary[key]) return dictionary[key];
  const patterns=[
   [/^سازنده: (.+)$/,'Author: $1'], [/^شناسه: (.+)$/,'ID: $1'], [/^واحد: (.+)$/,'Department: $1'],
   [/^آخرین ذخیره: (.+)$/,'Last saved: $1'], [/^(.+) · سند (\d+)$/,'$1 · Document $2'],
   [/^سند دریافت نشد\. کد پاسخ: (\d+)$/,'Unable to open document. Response: $1'],
   [/^دریافت فایل انجام نشد\. کد پاسخ: (\d+)$/,'Download failed. Response: $1'],
   [/^دریافت فهرست انجام نشد\. پاسخ سرور را در بازرس بررسی کنید\. \((\d+)\)$/,'Unable to load documents. Inspect the server response. ($1)'],
   [/^ذخیره انجام نشد\. پاسخ سرور را در بازرس بررسی کنید\. \((\d+)\)$/,'Save failed. Inspect the server response. ($1)']
  ];
  let output=key;
  for(const [pattern,replacement] of patterns) if(pattern.test(key)){output=key.replace(pattern,replacement);break;}
  for(const word of ['مهندسی','مالی','مدیر واحد','کارمند']) output=output.replaceAll(word,dictionary[word]);
  return output.replace(/[۰-۹]/g,char=>String(char.charCodeAt(0)-0x06f0)).replace(/[٠-٩]/g,char=>String(char.charCodeAt(0)-0x0660));
 }
 function translateNode(node) {
  if(!node.parentElement || node.parentElement.closest(excluded) || !node.data.trim()) return;
  let record=records.get(node);
  if(!record || node.data!==record.rendered) {record={source:node.data,rendered:node.data};records.set(node,record);}
  const key=normalized(record.source);
  const translated=lang==='en'?english(record.source):(persianCodeLabels[key]||record.source);
  if(node.data!==translated)node.data=translated;
  record.rendered=translated;
 }
 function walk(root) {
  if(root.nodeType===Node.TEXT_NODE) return translateNode(root);
  const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);let node;
  while((node=walker.nextNode())) translateNode(node);
 }
 const attributes=[];
 document.querySelectorAll('[placeholder],[aria-label]').forEach(element=>{
  for(const name of ['placeholder','aria-label']) if(element.hasAttribute(name)) attributes.push({element,name,source:element.getAttribute(name)});
 });
 function makeSwitch(parent){
  const group=document.createElement('div');group.className='language-switch';group.setAttribute('role','group');group.setAttribute('aria-label','Language / زبان');
  for(const [value,label] of [['en','English'],['fa','فارسی']]){const button=document.createElement('button');button.type='button';button.dataset.language=value;button.lang=value;button.textContent=label;button.onclick=()=>setLanguage(value);group.append(button);}
  parent.append(group);
 }
 makeSwitch(document.querySelector('.login-card'));
 document.querySelector('.login-card').prepend(document.querySelector('.login-card > .language-switch'));
 makeSwitch(document.querySelector('.header-controls'));
 document.querySelector('.header-controls').prepend(document.querySelector('.header-controls > .language-switch'));
 function setLanguage(value){
  lang=value==='en'?'en':'fa';
  document.documentElement.lang=lang;document.documentElement.dir=lang==='fa'?'rtl':'ltr';
  document.title=lang==='fa'?'آزمایشگاه اطلس | فضای کار اسناد':'Atlas Lab | Document workspace';
  document.querySelectorAll('[data-language]').forEach(button=>{button.classList.toggle('active',button.dataset.language===lang);button.setAttribute('aria-pressed',String(button.dataset.language===lang));});
  for(const item of attributes)item.element.setAttribute(item.name,lang==='en'?english(item.source):item.source);
  for(const [node] of records)if(!node.isConnected)records.delete(node);
  walk(document.body);
  try{localStorage.setItem('atlas-language',lang);}catch{}
 }
 // Observe only UI text. Never translate raw responses or document content.
 const observer=new MutationObserver(changes=>{
  for(const change of changes){if(change.type==='characterData')translateNode(change.target);else for(const node of change.addedNodes)walk(node);}
  for(const [node] of records)if(!node.isConnected)records.delete(node);
 });
 setLanguage(lang);observer.observe(document.body,{subtree:true,childList:true,characterData:true});
 const originalConfirm=window.confirm.bind(window);
 window.confirm=text=>originalConfirm(lang==='en'?english(text):text);
 window.atlasLocale=()=>lang;
})();
