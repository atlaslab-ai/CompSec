"""Serve the initialized SQLite snapshot to the maintenance client."""
import os
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def do_GET(self):
        path = Path(os.environ.get('DATA_DIR', '/data')) / 'backup.sqlite'
        if self.path not in ('/health', '/backup.sqlite') or not path.exists():
            self.send_error(404)
            return
        body = b'ok' if self.path == '/health' else path.read_bytes()
        self.send_response(200)
        self.send_header('Content-Type', 'application/octet-stream')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)


if __name__ == '__main__':
    ThreadingHTTPServer((os.environ.get('BIND', '0.0.0.0'), int(os.environ.get('PORT', '8081'))), Handler).serve_forever()
