"""Local document service for the Atlas Lab training environment (Python standard library)."""
import datetime
from contextlib import closing
import hashlib
import hmac
import json
import os
from pathlib import Path
import re
import secrets
import sqlite3
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

DATA = Path(os.environ.get('DATA_DIR', '/data'))
TOKENS = {}
LOCK = threading.RLock()
USERS = {
    'sara': ('s1', 'engineering', 'employee'),
    'reza': ('r1', 'engineering', 'employee'),
    'mina': ('m1', 'engineering', 'manager'),
    'omid': ('o1', 'finance', 'employee'),
    'neda': ('n1', 'finance', 'manager'),
}
SEED = [
    (1, 'engineering', 'sara', 'Release checklist', 'ENG-SARA-SEED: review release checklist.'),
    (2, 'engineering', 'reza', 'Capacity plan', 'ENG-REZA-SEED: capacity estimate 42 units.'),
    (3, 'engineering', 'mina', 'Team roadmap', 'ENG-MINA-SEED: roadmap for the next quarter.'),
    (4, 'finance', 'omid', 'Budget draft', 'FIN-OMID-SEED: fictional budget 75000 credits.'),
    (5, 'finance', 'neda', 'Audit schedule', 'FIN-NEDA-SEED: internal audit next month.'),
]


def initialize():
    DATA.mkdir(parents=True, exist_ok=True)
    with closing(sqlite3.connect(DATA / 'live.sqlite')) as db:
        db.execute('CREATE TABLE IF NOT EXISTS documents (id INTEGER PRIMARY KEY, unit TEXT, owner TEXT, title TEXT, content TEXT)')
        if not db.execute('SELECT count(*) FROM documents').fetchone()[0]:
            db.executemany('INSERT INTO documents VALUES (?,?,?,?,?)', SEED)
        db.commit()
        if not (DATA / 'backup.sqlite').exists():
            with closing(sqlite3.connect(DATA / 'backup.sqlite')) as dest:
                db.backup(dest)


def connect():
    db = sqlite3.connect(DATA / 'live.sqlite')
    db.row_factory = sqlite3.Row
    return db


def audit(user, action, doc, status):
    with LOCK:
        print(json.dumps({'time': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                          'event': 'request', 'method': action, 'status': status}), flush=True)


def permitted(user, doc, action):
    return user is not None


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def send(self, code, obj, kind='application/json'):
        body = obj if isinstance(obj, bytes) else json.dumps(obj).encode() if kind == 'application/json' else obj.encode()
        self.send_response(code)
        self.send_header('Content-Type', kind + '; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(body)

    def payload(self):
        size = int(self.headers.get('Content-Length', '0'))
        if not 0 < size <= 16384:
            raise ValueError('invalid size')
        obj = json.loads(self.rfile.read(size))
        if not isinstance(obj, dict):
            raise ValueError('object required')
        return obj

    def identity(self):
        return TOKENS.get(self.headers.get('Authorization', '').removeprefix('Bearer '))

    def do_GET(self):
        assets = {'/assets/images/atlas-logo.png': ('images/atlas-logo.png', 'image/png'),
                  '/assets/i18n.js': ('i18n.js', 'text/javascript'),
                  '/assets/fonts/Estedad.ttf': ('fonts/Estedad.ttf', 'font/ttf'),
                  '/assets/fonts/OFL.txt': ('fonts/OFL.txt', 'text/plain')}
        if self.path in assets:
            filename, kind = assets[self.path]
            return self.send(200, (Path(__file__).parent / filename).read_bytes(), kind)
        if self.path == '/health':
            return self.send(200, {'status': 'ok'})
        if self.path == '/':
            return self.send(200, (Path(__file__).with_name('index.html')).read_text(encoding='utf-8'), 'text/html')
        user = self.identity()
        if self.path == '/docs':
            if not user:
                return self.send(401, {'error': 'authentication required'})
            with closing(connect()) as db:
                rows = db.execute('SELECT id,unit,owner,title FROM documents WHERE unit=? ORDER BY id', (USERS[user][1],)).fetchall()
            return self.send(200, {'documents': [dict(r) for r in rows]})
        self.document('download' if self.path.endswith('/download') else 'read')

    def do_POST(self):
        if self.path != '/login':
            return self.send(404, {'error': 'not found'})
        try:
            obj = self.payload()
            name, password = obj.get('username', ''), obj.get('password', '')
            valid = isinstance(name, str) and isinstance(password, str) and name in USERS and hmac.compare_digest(password, USERS[name][0])
        except (ValueError, TypeError):
            return self.send(400, {'error': 'invalid request'})
        if not valid:
            return self.send(401, {'error': 'invalid credentials'})
        token = secrets.token_urlsafe(32)
        with LOCK:
            TOKENS[token] = name
        self.send(200, {'token': token, 'username': name, 'unit': USERS[name][1], 'role': USERS[name][2]})

    def do_PUT(self):
        self.document('edit')

    def document(self, action):
        match = re.fullmatch(r'/docs/([1-9][0-9]{0,8})(/download)?', self.path)
        if not match or (action == 'edit' and match[2]):
            return self.send(404, {'error': 'not found'})
        ident = int(match[1])
        user = self.identity()
        with closing(connect()) as db:
            row = db.execute('SELECT * FROM documents WHERE id=?', (ident,)).fetchone()
            code = 401 if not user else 404 if row is None else 403 if not permitted(user, row, action) else 200
            if code != 200:
                audit(user, action, ident, code)
                return self.send(code, {'error': 'access denied or not found'})
            if action == 'edit':
                try:
                    content = self.payload().get('content')
                    if not isinstance(content, str) or len(content) > 8192:
                        raise ValueError('invalid content')
                except (ValueError, TypeError):
                    audit(user, action, ident, 400)
                    return self.send(400, {'error': 'invalid content'})
                db.execute('UPDATE documents SET content=? WHERE id=?', (content, ident))
                db.commit()
                audit(user, action, ident, 200)
                return self.send(200, {'id': ident, 'content': content})
            audit(user, action, ident, 200)
            if action == 'download':
                return self.send(200, row['content'], 'text/plain')
            self.send(200, dict(row))


if __name__ == '__main__':
    initialize()
    ThreadingHTTPServer((os.environ.get('BIND', '0.0.0.0'), int(os.environ.get('PORT', '8080'))), Handler).serve_forever()
