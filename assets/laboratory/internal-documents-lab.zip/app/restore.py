"""Non-destructive restore drill; never connects to the live database."""
import hashlib
from contextlib import closing
import json
from pathlib import Path
import sqlite3
import tempfile
from urllib.request import urlopen
import os


def drill(url):
    blob = urlopen(url, timeout=5).read()
    with tempfile.TemporaryDirectory(prefix='atlas-restore-') as folder:
        path = Path(folder) / 'restored.sqlite'
        path.write_bytes(blob)
        with closing(sqlite3.connect('file:' + path.as_posix() + '?mode=ro', uri=True)) as db:
            assert db.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
            sample = db.execute('SELECT content FROM documents WHERE id=4').fetchone()
            assert sample and sample[0] == 'FIN-OMID-SEED: fictional budget 75000 credits.'
            assert db.execute('SELECT count(*) FROM documents').fetchone()[0] == 5
        return {'restore': 'ok', 'sample_id': 4, 'rows': 5, 'sha256': hashlib.sha256(blob).hexdigest(), 'destination': 'temporary, removed'}


if __name__ == '__main__':
    print(json.dumps(drill(os.environ.get('BACKUP_URL', 'http://backup:8081/backup.sqlite'))))
